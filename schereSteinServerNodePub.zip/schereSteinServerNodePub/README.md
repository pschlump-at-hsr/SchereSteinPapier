#Schere Stein Papier Server - Node

Starten mit npm start

Zum Starten der Demos:
1. *Im Terminal* npm start
2. Im Browser zugreifbar
- http://localhost:8080/getAnswer
- http://localhost:8080/play?playerName=Markus&playerHand=Stein
- http://localhost:8080/ranking
